# 04. PROCESOS PRODUCTIVOS

# CAPÍTULO 4: PROCESOS PRODUCTIVOS Y TECNOLOGÍA APLICADA

## 4.1 Procesos de Tratamiento de Agua

### 4.1.1 Agua Industrial y Acondicionamiento Técnico
El agua industrial requiere tratamientos específicos según su uso final en planta (enfriamiento, lavado, procesos químicos o agua de alimentación de calderas):
- **Clarificación y Coagulación:** Remoción de sólidos en suspensión y coloides mediante adición de sulfato de aluminio $[(SO_4)_3 Al_2]$ o sulfato ferroso $[SO_4 Fe]$, seguida de aglomeración en flóculos y decantación (fuente: Documento Tratamiento de Efluentes y Agua, 2023, diapositivas 25, 71).
- **Ablandamiento por Intercambio Iónico:** Proceso de sustitución estequiométrica $1:1$ de carga donde los cationes de dureza ($Ca^{2+}$, $Mg^{2+}$) presentes en el agua dura son retenidos por resinas catiónicas sintéticas y reemplazados por sodio ($Na^+$). Cuando el lecho se satura, se efectúa la regeneración con solución concentrada de salmuera ($NaCl$) en flujo descendente o contracorriente (fuente: Documento Adsorción e Intercambio Iónico, sección Intercambio Iónico; Documento Tratamiento de Efluentes y Agua, 2023, diapositiva 72).
- **Acondicionamiento Químico por Complejación:** Adición de hexametafosfato de sodio $[(PO_3 Na)_6]$, el cual forma el complejo soluble $[(PO_4)_6 Ca_2]Na_2$, impidiendo que el calcio precipite como incrustación (fuente: Documento Adsorción e Intercambio Iónico, sección Acondicionamiento de $H_2O$).

### 4.1.2 Potabilización del Agua
El proceso de potabilización para abastecimiento humano e industrial sigue la secuencia física y química estandarizada:
1. **Captación y Desbaste:** Toma de río o pozo con rejas gruesas para retención de gruesos y desarenador (fuente: Documento Tratamiento de Efluentes y Agua, 2023, diapositivas 64, 71).
2. **Mezcla Rápida y Coagulación-Floculación:** Dosificación de oxidantes y coagulantes para desestabilizar cargas eléctricas coloidales (fuente: Documento Tratamiento de Efluentes y Agua, 2023, diapositiva 71).
3. **Decantación y Filtración:** Separación de flóculos en decantadores e ingreso a filtros rápidos por gravedad cargados con mantos de arena o carbón granulado (fuente: Documento Tratamiento de Efluentes y Agua, 2023, diapositivas 71, 72).
4. **Desinfección y Acondicionamiento Final:** Cloración o desinfección UV, corrección de pH y almacenamiento en tanques elevados de reserva para distribución por red de presión (fuente: Documento Tratamiento de Efluentes y Agua, 2023, diapositivas 71, 72).

---

## 4.2 Generación de Vapor y Aire Comprimido Industrial

### 4.2.1 Vapor Industrial y Agua de Caldera
El agua natural contiene impurezas disueltas clasificadas en dureza temporaria (bicarbonatos) y dureza permanente (sulfatos, cloruros, nitratos). En Argentina, la dureza se mide comúnmente en grados franceses ($1\text{ }^\circ\text{f} = 10\text{ ppm de }CaCO_3$), categorizando las aguas desde *muy blanda* ($0-2\text{ }^\circ\text{f}$) hasta *muy dura* ($>12\text{ }^\circ\text{f}$) (fuente: Documento Adsorción e Intercambio Iónico, sección Tratamiento de Aguas para la Producción de Vapor).

```
        Escala de Dureza Francesa (°f)
  0       2       4       7       12       (°f)
  |-------|-------|-------|-------|---------->
 Very Soft  Soft  Semi-Hard  Hard  Very Hard
```

- **Inconvenientes Operativos:** 
  - *Incrustaciones Pétreas:* Causadas por disminución de solubilidad al elevar la temperatura ($CaSO_4$, $CaCO_3$, $Mg(OH)_2$, $CaSiO_3$), formando costras aislantes térmicas que sobrecalientan el acero de los tubos y provocan deformaciones o colapsos (fuente: Documento Adsorción e Intercambio Iónico, sección Preparación del Agua para Calderas).
  - *Arrastres y Golpes de Ariete:* Elevados sólidos disueltos incrementan la viscosidad, produciendo ebulliciones tumultuosas, espuma y arrastre de gotas acuosas hacia las conducciones de vapor, generando golpes de ariete e impactos destructivos en turbinas (fuente: Documento Adsorción e Intercambio Iónico, sección Tratamiento de Aguas para la Producción de Vapor).
  - *Corrosión por Gases Disueltos:* El oxígeno ($O_2$) y el anhídrido carbónico ($CO_2$) causan picaduras severas en el metal.
- **Técnicas de Purificación de Agua de Caldera:**
  1. *Desendurecimiento Químico:* Método del carbonato bárico y adición de fosfato trisódico $[PO_4 Na_3]$ para precipitar dureza antes del ingreso (fuente: Documento Adsorción e Intercambio Iónico, sección Purificación del Agua para Calderas).
  2. *Desaireación Térmica y Físico-Química:* Disminución de solubilidad de gases mediante calentamiento con vapor directo, vacío y eyectores en columnas de desorción (*stripping*). Eliminación química mediante paso por lecho reactivo de hierro metálico (método Kestner) que fija el oxígeno como $Fe(OH)_3$ (fuente: Documento Adsorción e Intercambio Iónico, sección Purificación del Agua para Calderas).

### 4.2.2 Aire Comprimido y Secado Neumático
El aire comprimido requiere la eliminación del agua en fase vapor para evitar condensaciones en redes de distribución e instrumentos:
- **Secado por Adsorción:** Paso del aire comprimido a través de lechos fijos de gel de sílice, alúmina activada o tamices moleculares ($4\text{ \AA}$), alcanzando puntos de rocío de hasta $-75\text{ }^\circ\text{C}$ (fuente: Documento Adsorción e Intercambio Iónico, sección Adsorbentes).
- **Adsorción a Presión Alterna (PSA - *Pressure Swing Adsorption*):** Regeneración del lecho saturado por despresurización rápida a presión atmosférica o vacío, utilizando una pequeña fracción del gas seco sin requerir aporte de calor externo (fuente: Documento Adsorción e Intercambio Iónico, sección Adsorción a Presión Alterna).

---

## 4.3 Infraestructura, Montajes e Instalaciones Electromecánicas

La ejecución física de los servicios industriales involucra obras civiles y montajes mecánicos especializados:
- **Obras de Captación e Hidráulicas:** Tomas de agua en cauces, desarenadores de flujo continuo, estaciones de bombeo de baja y alta presión y tanques elevados de reserva (fuente: Documento Tratamiento de Efluentes y Agua, 2023, diapositiva 71).
- **Reactores y Conducciones:** Instalación de colectores principales, unidades de ecualización agitadas, mezcladores estáticos de vórtice turbulento y tuberías inoxidables o de PVC técnico para distribución de fluidos (fuente: Documento Separación de Fases, sección Mezcladores Estáticos; Tesis Troncoso, 2024, Sección 1.3.3.6).
- **Sistemas de Lecho Fijo y Expandido:** Recipientes a presión de $0,3\text{ m}$ a $1,2\text{ m}$ de espesor de lecho soportados sobre placas perforadas, operados en flujo descendente para evitar fluidización no deseada de partículas (fuente: Documento Adsorción e Intercambio Iónico, sección Equipo de Adsorción).

---

## 4.4 Equipamiento y Tecnología Aplicada en Depuración de Efluentes

El tratamiento de Residuos Industriales Líquidos (RILes) y efluentes se estructura en tres etapas secuenciales:

| Etapa | Proceso / Unidad | Mecanismo Operativo |
| :--- | :--- | :--- |
| **Preliminar** | Rejas mecánicas y tamices rotativos | Retención física de sólidos gruesos y finos (fuente: Doc. Tratamiento Efluentes, diap. 64-65) |
| **Preliminar** | Ecualización / Compensación | Homogeneización de caudal y carga orgánica en tanques agitados (fuente: Doc. Tratamiento Efluentes, diap. 65) |
| **Primario** | Sedimentación primaria circular | Separación gravitacional de sólidos sedimentables con puente barredor (fuente: Doc. Tratamiento Efluentes, diap. 66) |
| **Primario** | Flotación por Aire Disuelto (DAF) | Remoción de aceites, grasas y flotantes mediante microburbujas de aire (fuente: Doc. Tratamiento Efluentes, diap. 66) |
| **Secundario** | Lodos Activados (Proceso Intensivo) | Degradación aeróbica de $DBO_5$ en reactor aireado con recirculación de biomasa (fuente: Doc. Tratamiento Efluentes, diap. 67-68) |
| **Secundario** | Lagunas Facultativas / Aireadas | Degradación biológica extensa por acción conjunta de bacterias heterótrofas y algas (fuente: Doc. Tratamiento Efluentes, diap. 67; Tesis Troncoso, diap. 10) |
| **Secundario** | Reactores Anaeróbicos UASB | Digestión metanogénica en manto de lodos de flujo ascendente sin aireación (fuente: Doc. Tratamiento Efluentes, diap. 68) |
| **Terciario** | Membranas y Desinfección | Ultrafiltración, ósmosis inversa, cloración y luz UV para eliminación de nutrientes ($N, P$) y patógenos (fuente: Doc. Tratamiento Efluentes, diap. 64; Tesis Troncoso, diap. 10) |

---

## 4.5 Impacto Ambiental y Reúso Agrícola (ACRE)

- **Gestión de Lodos Residuales:** Los lodos producidos en los sedimentadores primarios y secundarios se someten a digestión anaeróbica para estabilización de biomasa. Los lodos deshidratados (mediante prensas de banda o centrífugas) se destinan a acondicionamiento de suelos agrícolas como fertilizante o disposición en rellenos sanitarios (fuente: Video Operación y Proceso de Tratamiento; Tesis Troncoso, 2024, Sección 1.3.3.4).
- **Régimen ACRE y Vuelco Cero en Mendoza:** Regulado por la Res. 400/03 e incentivado por las Res. 51/20 y 52/20 del DGI, exige que los efluentes depurados sean vertidos a Áreas de Cultivos Restringidos Especiales (ACRE) donde se implantan cultivos autorizados (forestales, forrajes como alfalfa), prohibiendo el volcamiento a cauces públicos sin reúso total (fuente: Tesis Troncoso, 2024, Sección 1.3.3.1 - 1.3.3.2).

---

## Vacíos de Información
- **Especificaciones Neumáticas de Compresores:** `[NO ENCONTRADO EN FUENTES]` Las fuentes del cuaderno no contienen curvas de rendimiento, presiones de trabajo en bar ni caudales $FAD$ ($m^3/min$) para los sistemas de aire comprimido.