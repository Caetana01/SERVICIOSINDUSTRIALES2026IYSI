# 06. CONCLUSIONES

# 6. Conclusiones

## 6. Conclusiones

1. **Sostenibilidad Sistémica de los Servicios Industriales:** Los servicios industriales (agua, potabilización, vapor, aire comprimido) constituyen el sostén operativo de la ingeniería de procesos. En entornos con restricción hídrica severa, la gestión eficiente del agua de proceso debe articular el acondicionamiento preventivo con el tratamiento posterior de efluentes.
2. **Importancia del Acondicionamiento Térmico en Calderas:** La presencia de dureza calcárea y magnésica origina incrustaciones pétreas aislantes que reducen drásticamente la transferencia de calor y comprometen la integridad mecánica del acero. El ablandamiento por intercambio iónico, la deaireación técnica (térmica y con lechos de hierro Kestner) y la dosificación de complejantes son indispensables para evitar paradas catastróficas y arrastres de humedad.
3. **El Modelo Mendoza de Reúso Agrícola y Vuelco Cero:** La provincia de Mendoza ha consolidado un modelo pionero mediante la reglamentación ACRE (Res. 400/03) y la exigencia de Vuelco Cero (Res. 51/20 y 52/20 DGI). La depuración de RILes y efluentes mediante sistemas combinados (preliminar, primario DAF/sedimentación, secundario biológico y terciario) permite reinsertar el agua tratada en la producción agrícola de forrajes y bosques forestales, mitigando la escasez del recurso hídrico.
4. **Fortalecimiento Institucional:** La reciente centralización de las funciones de regulación, control tarifario y calidad de agua potable y saneamiento bajo la órbita de DIRCAS (DGI) unifica la gobernanza del agua en la provincia, optimizando la fiscalización de operadores y la planificación estratégica hacia el 2050.