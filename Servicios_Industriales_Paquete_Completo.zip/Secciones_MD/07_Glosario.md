# 07. GLOSARIO TÉCNICO

## 7. Glosario Técnico

- **ACRE (Área de Cultivos Restringidos Especiales):** Zona agrícola delimitada donde se destinan los efluentes depurados en un establecimiento para riego de cultivos autorizados bajo normas biológicas y sanitarias del DGI.
- **AC (Carbón Activado):** Material poroso carbonoso de elevada superficie específica utilizado en adsorción física y química para remover contaminantes orgánicos, olores y colorantes.
- **AMR / RIL:** Residuo Industrial Líquido generado en procesos de fabricación o servicios auxiliares.
- **AySAM:** Agua y Saneamiento Mendoza SAPEM, empresa provincial encargada de la provisión de agua potable y saneamiento cloacal.
- **DAF (*Dissolved Air Flotation*):** Flotación por aire disuelto, técnica de clarificación primaria mediante microburbujas de aire para remover grasas, aceites y sólidos de baja densidad.
- **DBO5 (Demanda Bioquímica de Oxígeno a 5 días):** Muestra la cantidad de oxígeno consumido por microorganismos para degradar la materia orgánica biodegradable a $20\text{ }^\circ\text{C}$.
- **DGI:** Departamento General de Irrigación, entidad autárquica de la provincia de Mendoza encargada de la administración del agua pública.
- **DIRCAS:** Dirección de Regulación y Control de Agua y Saneamiento, organismo creado en 2025 dentro del DGI para absorción de las funciones del disuelto EPAS.
- **DQO (Demanda Química de Oxígeno):** Medida de la cantidad total de oxígeno requerida para oxidar químicamente la totalidad de la materia orgánica disoluta y suspendida.
- **Grado Francés ($^\circ\text{f}$):** Unidad de dureza del agua equivalente a $10\text{ mg/L}$ ($10\text{ ppm}$) de equivalente de carbonato de calcio ($CaCO_3$).
- **IP (Índice de Peligrosidad Industrial):** Parámetro reglamentado por Res. 52/20 DGI para clasificar la toxicidad y peligrosidad de los vertidos de un establecimiento.
- **PSA (*Pressure Swing Adsorption*):** Adsorción por oscilación de presión, proceso de separación y secado de gases por variación periódica de presión.
- **RAS (Relación de Adsorción de Sodio):** Índice químico que evalúa el riesgo de sodificación del suelo al ser irrigado con efluentes.
- **RUE:** Registro Único de Establecimientos del Departamento General de Irrigación para control de contaminación hídrica.
- **UASB (*Upflow Anaerobic Sludge Blanket*):** Reactor anaeróbico de flujo ascendente y manto de lodo, tecnología de digestión biológica intensiva para efluentes concentrados.