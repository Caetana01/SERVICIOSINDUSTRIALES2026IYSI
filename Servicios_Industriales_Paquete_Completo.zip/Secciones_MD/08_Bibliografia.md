# 08. BIBLIOGRAFÍA

## 8. Bibliografía y Fuentes de Consulta

1. **Aguas Mendocinas (AySAM SAPEM)** (2016 - 2026). *Plan Estratégico de Aguas Mendocinas (PEAM) y Portal de Obras e Infraestructura*. Mendoza, Argentina.
2. **Departamento General de Irrigación (DGI)** (1884 - 2025). *Ley General de Aguas (1884); Resolución N° 778/1996 HTA; Resolución N° 400/2003 HTA (Reglamento ACRE); Resoluciones N° 51/2020 y 52/2020 HTA; Creación de la DIRCAS (Ley Provincial 2024/2025)*. Mendoza, Argentina.
3. **Ente Provincial de Agua y Saneamiento (EPAS)** (1996). *Normas de Calidad de Agua y Efluentes (Resolución N° 35/1996)*. Mendoza, Argentina.
4. **Facultad de Ingeniería - Universidad Nacional de Cuyo (UNCuyo)** (2023). *Tratamiento de Agua, Efluentes y Residuos en la Industria (Cátedra Industrias y Servicios I)*. Mendoza, Argentina.
5. **Facultad de Ciencias Aplicadas a la Industria / FI UNCuyo**. *Adsorción e Intercambio Iónico: Guía Técnica de Operaciones Unitarias*. Mendoza, Argentina.
6. **Facultad de Ciencias Aplicadas a la Industria / FI UNCuyo**. *Separación de Fases: Mecánica de Fluidos y Equipos Industrial de Clasificación*. Mendoza, Argentina.
7. **Facultad de Ciencias Exactas - UNCuyo**. *Sistemas Coloidales, Fenómenos Superficiales y Purificación de Coloides (Documento FQU2TGYH)*. Mendoza, Argentina.
8. **Troncoso Scavarda, María C.** (2024). *Propuesta de Gestión Sustentable de Efluentes Cloacales en el Distrito de Agrelo, Luján de Cuyo, Mendoza (Tesis de Grado)*. Universidad Nacional de Cuyo, Mendoza, Argentina.
9. **Edwin Oswaldo / WEF** (S.F.). *Operación y Proceso de Tratamiento de Aguas Residuales (Video Técnico Subtitulado)*.