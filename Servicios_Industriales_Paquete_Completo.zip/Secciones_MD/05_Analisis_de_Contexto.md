# 05. ANÁLISIS DE CONTEXTO

# CAPÍTULO 5: ANÁLISIS DE CONTEXTO Y MARCO REGULATORIO

## 5.1 Sector Nacional y Provincial (Mendoza)

### 5.1.1 Localización y Geografía Operativa
En la provincia de Mendoza, el 98,5% de las actividades agro-urbano-industriales se concentran en tres oasis de riego (Norte, Centro y Sur) alimentados por los ríos Mendoza, Tunuyán, Diamante, Atuel y Malargüe. El Oasis Norte integra el Área Metropolitana de Mendoza (AMM), albergando el 60% de la población provincial en los departamentos de Capital, Las Heras, Guaymallén, Godoy Cruz, Maipú, Luján de Cuyo y Lavalle (fuente: Tesis Troncoso, 2024, Sección 1.3.3).

### 5.1.2 Demanda y Mercado de Servicios
Según el Censo Nacional 2022 (INDEC, 2023), Mendoza registró un crecimiento poblacional del 14% respecto a 2010. Este aumento incrementó exponencialmente los volúmenes de efluentes urbanos e industriales y la demanda de agua potable, sobrepasando las capacidades nominales de diseño en plantas depuradoras como Rivadavia (superada en un 12%) y Junín (superada en un 27%) (fuente: Tesis Troncoso, 2024, Sección 1.3.3.3 - 1.3.3.4).

### 5.1.3 Marco Normativo Específico
El régimen legal sobre servicios industriales y efluentes se articula en tres niveles:

1. **Marco Constitucional y Nacional:**
   - *Artículo 41 de la Constitución Nacional (1994):* Consagra el derecho a un ambiente sano y establece la potestad de la Nación para fijar Leyes de Presupuestos Mínimos de Protección Ambiental (fuente: Tesis Troncoso, 2024, Sección 1.3.2.1; Doc. Tratamiento Efluentes, diap. 3).
   - *Ley N° 25.675 (General del Ambiente) y Ley N° 24.051 (Residuos Peligrosos):* Marco nacional para la gestión integral de residuos industriales y peligrosos (fuente: Doc. Tratamiento Efluentes, diap. 3).
   - *Ley N° 25.688 (Régimen de Gestión Ambiental del Agua):* Define a la cuenca hídrica como unidad indivisible de gestión y promueve la creación de comités interjurisdiccionales (fuente: Tesis Troncoso, 2024, Sección 1.3.2.1).

2. **Marco Provincial de Mendoza:**
   - *Ley General de Aguas de 1884:* Establece al Departamento General de Irrigación (DGI) como autoridad autárquica y máxima del agua provincial (fuente: Tesis Troncoso, 2024, Sección 1.3.3.1).
   - *Resolución N° 778/1996 DGI:* Reglamento General para el Control de Contaminación Hídrica. Obliga a establecimientos industriales a registrarse en el Registro Único de Establecimientos (RUE) y fija límites máximos permitidos de vertido (fuente: Tesis Troncoso, 2024, Sección 1.3.3.1).
   - *Resolución N° 400/2003 DGI:* Reglamento de Áreas de Cultivos Restringidos Especiales (ACRE). Delimita el uso agrícola de efluentes tratados según la categoría del tratamiento (Categoría A: primario para forestales y forrajes; Categoría B: secundario para cultivos de consumo con restricciones) (fuente: Tesis Troncoso, 2024, Sección 1.3.3.1 - 1.3.3.2).
   - *Resoluciones N° 51/2020 y 52/2020 DGI:* Modificaron la Res. 778/96 incorporando el Índice de Peligrosidad Industrial (IP), fijando límites de conductividad eléctrica por cuenca e instituyendo la exigencia de Proyectos de Reúso para alcanzar el Vuelco Cero (fuente: Tesis Troncoso, 2024, Sección 1.3.3.1).
   - *Nueva Ley de Saneamiento y Creación de DIRCAS (2024-2025):* Tras la disolución del EPAS a fines de 2024, la Dirección de Regulación y Control de Agua y Saneamiento (DIRCAS) bajo el DGI asumió la regulación de tarifas, control de inversiones de operadores y fiscalización de la calidad del agua potable y saneamiento en toda la provincia (fuente: DGI-WEB, 24 de marzo de 2025).

3. **Exigencias de Calidad de Vertido (Resolución N° 52/2020 DGI):**
   Los efluentes vertidos o destinados a ACRE deben cumplir límites strictly verificados en laboratorio (ejemplo Planta Agrelo): $Cl^- < 64\text{ mg/L}$, $SO_4^{2-} < 17,17\text{ mg/L}$, $Na < 81\text{ mg/L}$, $RAS < 1,84$, metales pesados ($As, Cd, Cr, Hg, Pb < 0,005 - 0,05\text{ mg/L}$) y sólidos sedimentables a 2 horas $<0,1\text{ mL/L}$ (fuente: Tesis Troncoso, 2024, Tablas 1, 2 y 3).

### 5.1.4 Proveedores y Cadena de Valor
Los servicios sanitarios y de abastecimiento de agua son operados mayoritariamente por la empresa estatal Agua y Saneamiento Mendoza (AySAM SAPEM), operadores municipales (Luján de Cuyo, Maipú, Tupungato) y cooperativas comunitarias. La cadena de proveedores de tecnología incluye fabricantes de plantas compactas (Hidritec, Huber, Spena Group, GE Water) y productos químicos de proceso (fuente: Tesis Troncoso, 2024, Sección 1.3.3.3; Doc. Tratamiento Efluentes, diap. 64, 71).

---

## 5.2 Sector Externo y Tendencias Globales

- **Fabricantes y Tecnología Global:** Desarrollo de reactores anaeróbicos de alta tasa (UASB) y sistemas MBR (reactores biológicos de membrana) por firmas internacionales (fuente: Doc. Tratamiento Efluentes, diap. 68, 73).
- **Normas e Indicadores Internacionales:** Objetivos de Desarrollo Sostenible (ODS) de la Organización de las Naciones Unidas, específicamente el ODS 6 (Agua Limpia y Saneamiento) y guías de la OMS/ONU-Hábitat para el reúso seguro de efluentes (fuente: Tesis Troncoso, 2024, Sección 1.3.1.1).

---

## 5.3 Actualidad y Perspectivas Futuras

- **Escasez e Innovación Tecnológica:** En el marco del Plan Estratégico de Aguas Mendocinas (PEAM 2026-2030 con proyección a 2050), se ejecutan obras de envergadura como la Colectora Máxima Noreste El Paramillo y la ampliación de redes en calle Yrigoyen (fuente: Aguas Mendocinas AYSAM, noticias 2025-2026).
- **Telemetría y Control Digital:** Incorporación de sistemas de telemetría subterránea y monitoreo hídrico móvil (MIDO) en el DGI para un control transparente del recurso (fuente: DGI-WEB, marzo 2025).

---

## Vacíos de Información
- **Comercio Exterior y Estadísticas de Importación/Exportación:** `[NO ENCONTRADO EN FUENTES]` Las fuentes no registran montos ni volúmenes de importación o exportación de equipos de servicios industriales (calderas, compresores, resinas) en Argentina.