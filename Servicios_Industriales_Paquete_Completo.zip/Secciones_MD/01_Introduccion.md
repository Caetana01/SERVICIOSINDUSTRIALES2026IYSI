# 01. INTRODUCCIÓN

# SERVICIOS INDUSTRIALES: INFORME TÉCNICO UNIVERSITARIO

## 1. Introducción

El presente informe técnico universitario, desarrollado para la cátedra Industrias y Servicios I de la Facultad de Ingeniería de la Universidad Nacional de Cuyo (UNCuyo), aborda el estudio integral y sistémico de los **Servicios Industriales**. En el ámbito de la ingeniería de procesos, los servicios industriales constituyen las prestaciones auxiliares e infraestructura crítica que abastecen, acondicionan y gestionan los insumos fluidodinámicos y energéticos indispensables para el funcionamiento continuo y seguro de una planta productiva.

El alcance analítico de este informe comprende seis ejes fundamentales:
1. **Agua Industrial:** Acondicionamiento de fuentes superficiales y subterráneas, clarificación, filtración, desendurecimiento, ablandamiento por intercambio iónico y desaireación de agua para alimentación de calderas y circuitos auxiliares de enfriamiento y lavado.
2. **Potabilización del Agua:** Tecnologías de clarificación, coagulación-floculación, filtración sobre lecho poroso y desinfección para asegurar la provisión de agua segura para consumo humano e higiene del personal.
3. **Vapor Industrial:** Generación, acondicionamiento de agua de caldera y gestión de parámetros de prevención de incrustaciones salinas y corrosión por gases disueltos ($O_2$ y $CO_2$).
4. **Aire Comprimido Industrial:** Generación y acondicionamiento neumático para instrumentación y accionamientos.
5. **Montajes e Infraestructura:** Diseño e instalación de conducciones, obras de captación, reservorios e instalaciones electromecánicas auxiliares.
6. **Tecnología Aplicada e Impacto Ambiental:** Procesos de depuración de Residuos Industriales Líquidos (RILes) y efluentes domiciliarios, tratamiento primario, secundario (lodos activados y lagunas) y terciario, alineados al régimen de reuso agrícola en Áreas de Cultivos Restringidos Especiales (ACRE) y la política ambiental de Vuelco Cero en cuencas hídricas semiáridas.

---