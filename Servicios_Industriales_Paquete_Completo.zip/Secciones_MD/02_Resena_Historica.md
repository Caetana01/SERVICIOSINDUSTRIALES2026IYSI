# 02. RESEÑA HISTÓRICA

# 2. Reseña Histórica

La gestión institucional, técnica y normativa de los servicios industriales y los recursos hídricos en la provincia de Mendoza —asentada en la diagonal árida sudamericana con precipitaciones anuales de solo 200 mm a 250 mm— presenta una evolución histórica de más de un siglo, caracterizada por la búsqueda constante de soberanía hídrica y preservación del recurso.

```
1884                      1994                  1996 - 2003           2024 - 2025
 |-------------------------|-------------------------|---------------------|
Ley General            Reforma Art. 41/124       Res. 778/96 (RUE)     Disolución EPAS /
de Aguas (DGI)         Presupuestos Mínimos      Res. 400/03 (ACRE)    Creación DIRCAS
```

### 2.1 Hitos Normativos e Institucionales Locales
- **Ley General de Aguas (1884):** Constituye la piedra angular del derecho hídrico provincial y nacional. Sancionada en 1884, instituyó al Departamento General de Irrigación (DGI) como un organismo público autárquico, autónomo y descentralizado, con atribuciones constitucionales para la administración, distribución y regulación del dominio público hídrico provincial (fuente: Tesis Troncoso, 2024, Sección 1.3.3.1).
- **Reforma Constitucional Nacional de 1994:** Introdujo el Artículo 41 (derecho a un ambiente sano y potestad de la Nación para dictar leyes de presupuestos mínimos de protección ambiental) y el Artículo 124 (dominio originario de los recursos naturales en cabeza de las provincias), ratificando la autonomía de Mendoza sobre sus cuencas hídricas (fuente: Tesis Troncoso, 2024, Sección 1.3.2.1).
- **Reglamentación del Control de Contaminación y Reúso Agrícola (1996 - 2003):** 
  - *Resolución N° 778/1996 DGI:* Emitida el 23 de diciembre de 1996, estableció el Reglamento General para el Control de Contaminación Hídrica y creó el Registro Único de Establecimientos (RUE) para el control de vertidos industriales a cauces públicos (fuente: Tesis Troncoso, 2024, Sección 1.3.3.1; Documento Tratamiento de Efluentes y Agua, 2023, diapositiva 3).
  - *Resolución N° 400/2003 DGI:* Sancionada el 4 de julio de 2003, reglamentó las Áreas de Cultivos Restringidos Especiales (ACRE), normando el reúso de efluentes depurados en agricultura (fuente: Tesis Troncoso, 2024, Sección 1.3.3.1).
  - *Resoluciones N° 51/2020 y 52/2020 DGI:* Actualizaron integralmente el marco de volcado e introdujeron el concepto de Proyecto de Reúso y Vuelco Cero (fuente: Tesis Troncoso, 2024, Sección 1.3.3.1).
- **Centralización Regulatoria en DIRCAS (2024 - 2025):** A fines de 2024, la Legislatura Provincial sancionó la ley que derogó la Ley 6044/1993 y disolvió el Ente Provincial de Agua y Saneamiento (EPAS). Las competencias regulatorias, tarifarias y de control del agua potable y saneamiento fueron transferidas integralmente al DGI, creándose en marzo de 2025 la Dirección de Regulación y Control de Agua y Saneamiento (DIRCAS) (fuente: DGI-WEB, 24 de marzo de 2025).

### 2.2 Evolución de la Infraestructura de Depuración Provincial
En la cuenca del Río Mendoza (Oasis Norte), donde se concentra el 60% de la población provincial en el Área Metropolitana de Mendoza (AMM), el saneamiento industrial y domiciliario evolucionó hacia grandes complejas depuradoras comunitarias:
- **Campo Espejo (Las Heras):** Trata un caudal de $1.500\text{ l/s}$ ($128.000\text{ m}^3\text{/día}$) mediante 11 series de lagunas de estabilización, volcando sus efluentes a un ACRE externo (fuente: Tesis Troncoso, 2024, Sección 1.3.3.3).
- **El Paramillo (Lavalle):** Trata un caudal de $1.753\text{ l/s}$ ($151.475\text{ m}^3\text{/día}$) mediante 4 series de lagunas de estabilización. Conjuntamente con Campo Espejo, depuran más del 75% de los efluentes urbanos e industriales de la provincia, irrigando una superficie de $12.000\text{ ha}$ (fuente: Tesis Troncoso, 2024, Sección 1.3.3.3).
- **Planta Depuradora Agrelo (Luján de Cuyo):** Puesta en marcha en mayo de 2020 para reemplazar 1.500 pozos sépticos domiciliarios e industriales. Trata un caudal inicial de $216\text{ m}^3\text{/día}$ ($6.500\text{ m}^3\text{/mes}$) mediante lagunas aireadas facultativas, piletas de sedimentación de helmintos y cloración, derivando el agua tratada al ACRE Agrelo (fuente: Tesis Troncoso, 2024, Sección 1.3.3.6, MendoVoz 2020).

---

## Vacíos de Información
- **Datos Históricos sobre Instalaciones de Aire Comprimido y Vapor:** `[NO ENCONTRADO EN FUENTES]` Las fuentes documentales del cuaderno no registran antecedentes cronológicos ni fechas de instalación de las primeras redes de vapor o aire comprimido a nivel industrial provincial o nacional.