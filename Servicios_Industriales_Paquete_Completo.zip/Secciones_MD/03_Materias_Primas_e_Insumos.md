# 03. MATERIAS PRIMAS E INSUMOS

# CAPÍTULO 3: MATERIAS PRIMAS E INSUMOS

## 3.1 Recursos Hídricos

En regiones semiáridas como la provincia de Mendoza, el insumo primario esencial de los servicios industriales es el **agua bruta**.
- **Fuentes Superficiales:** Proviene principalmente del agua de fusión de las masas de hielo de la Cordillera de los Andes, distribuida a través de los ríos Mendoza, Tunuyán, Diamante, Atuel y Malargüe. En el Oasis Norte, el Río Mendoza abastece tanto al consumo urbano como a los complejos industriales del Área Metropolitana (fuente: Tesis Troncoso, 2024, Sección 1.3.3).
- **Fuentes Subterráneas:** Acuíferos captados mediante perforaciones y pozos profundos. En zonas agrícolas o industriales no conectadas a redes de superficie, el bombeo subterráneo suministra agua bruta para acondicionamiento técnico (fuente: Documento Tratamiento de Efluentes y Agua, 2023, diapositiva 15; Tesis Troncoso, 2024, Sección 1.3.3.6).

---

## 3.2 Insumos Químicos y Sólidos Tecnológicos

El acondicionamiento del agua bruta, la potabilización, la preparación de agua de calderas y el tratamiento de efluentes requieren el uso sistemático de insumos químicos y materiales porosos especificados en las fuentes:

### A. Coagulantes, Floculantes y Acondicionadores de pH
- **Sulfato de Aluminio $[(SO_4)_3 Al_2]$ y Sulfato Ferroso $[SO_4 Fe]$:** Sales metálicas empleadas para la clarificación y coagulación. Al hidrolizarse en medio acuoso, forman hidróxidos gelatinosos (flóculos) que atrapan la materia en suspensión (fuente: Documento Tratamiento de Efluentes y Agua, 2023, diapositiva 25).
- **Correctores de Alcalinidad:** Cal hidratada $[Ca(OH)_2]$, carbonato de sodio $[CO_3 Na_2]$ e hidróxido de sodio $[NaOH]$, adicionados cuando el agua bruta carece de suficiente concentración de bicarbonatos para reaccionar con los coagulantes o durante el desendurecimiento químico (fuente: Documento Tratamiento de Efluentes y Agua, 2023, diapositiva 25).
- **Agentes Flotantes y Coadyuvantes:** En procesos de flotación de minerales e impurezas se emplean espumantes (alcoholes alifáticos pesados, aceite de pino), colectores (xantogenatos $NaS\cdot CS\cdot OR$), promotores ($HS\cdot PS\cdot (OR)_2$) y modificadores como sulfato de cobre $[SO_4 Cu]$ (fuente: Documento Separación de Fases, sección Flotación).

### B. Materiales Adsorbentes
- **Carbón Activado (AC):** Producido a partir de madera, lignito, carbón fósil, cáscara de nuez o hueso. Disponible en presentación en polvo (PAC) y granulado (GAC). El PAC presenta un costo equivalente a la mitad del GAC. Se regenera térmicamente en presencia de aire húmedo a $250\text{ }^\circ\text{C}$ con pérdidas de material cercanas al 10% (fuente: Documento Adsorción e Intercambio Iónico, secciones Adsorbentes y Adsorción para Líquidos).
- **Tamices Moleculares y Zeolitas:** Aluminosilicatos naturales o sintéticos con poros regulares de $4\text{ \AA}$ a $5\text{ \AA}$. Utilizados para secado profundo de gases (puntos de rocío de $-75\text{ }^\circ\text{C}$) y separación de parafinas lineales (fuente: Documento Adsorción e Intercambio Iónico, sección Adsorbentes).
- **Otros Adsorbentes:** Gel de sílice, alúmina activada y tierras de Fuller (silicatos naturales de aluminio y magnesio para decoloración y neutralización de aceites) (fuente: Documento Adsorción e Intercambio Iónico, sección Adsorbentes).

### C. Resinas de Intercambio Iónico
- **Resinas Catiónicas:** Polímeros de poliestireno reticulado con grupos funcionales de ácido fuerte (sulfónicos $-SO_3^-$) o ácido débil (carboxílicos $-COOH^-$), balanceados con contraiones móviles $H^+$ o $Na^+$ para ablandamiento y desmineralización (fuente: Documento Adsorción e Intercambio Iónico, sección Intercambio Iónico).
- **Resinas Aniónicas:** Polímeros con grupos de base fuerte (amonio cuaternario $-N^+(CH_3)_3$) o base débil (amino $-N^+H_3$), balanceados con $OH^-$ o $Cl^-$ (fuente: Documento Adsorción e Intercambio Iónico, sección Intercambio Iónico).
- **Regenerantes:** Cloruro de sodio ($NaCl$, salmuera para regeneración de ablandadores), ácido clorhídrico ($HCl$) y soda cáustica ($NaOH$) (fuente: Documento Tratamiento de Efluentes y Agua, 2023, diapositiva 17).

---

## 3.3 Logística de Abastecimiento e Insumos Operativos

- **Transporte y Distribución Hídrica:** El suministro de agua bruta se realiza mediante canales primarios y secundarios regulados por el DGI e Inspecciones de Cauce.
- **Evacuación Discontinua y Transporte Atmosférico:** En áreas no urbanizadas ni dotadas de colectoras cloacales, la evacuación de efluentes domiciliarios e industriales requería el uso de camiones atmosféricos para el desagote de pozos sépticos, esquema reemplazado por estaciones de bombeo y plantas depuradoras como Agrelo (fuente: Tesis Troncoso, 2024, Sección 1.3.3.6).
- **Regeneración in situ:** Las plantas industriales minimizan el transporte continuo de resinas y carbón mediante ciclos automáticos de regeneración *in situ* con vapor de agua, salmuera o gases inertes (fuente: Documento Adsorción e Intercambio Iónico, sección Equipos).

---

## 3.4 Aspectos Críticos

1. **Emergencia Hídrica Permanente:** La provincia acumula más de dos décadas de escurrimientos hidrológicos por debajo del promedio histórico en la cuenca andina, obligando al DGI a declarar la emergencia hídrica permanente y exigir eficiencias de uso superiores al 80% (fuente: Tesis Troncoso, 2024, Sección 1.3.3).
2. **Fluctuación Estacional de Carga y Caudal:** Las industrias agroalimentarias (bodegas, conserveras) generan picos estacionales de efluentes líquidos con alta carga orgánica ($DBO_5$ y $DQO$), requiriendo unidades de ecualización o compensación previa (fuente: Documento Tratamiento de Efluentes y Agua, 2023, diapositiva 10).
3. **Incrustaciones y Corrosión por Calidad Salina:** Las aguas subterráneas y de escurrimiento en Mendoza presentan elevados grados de dureza (expresada en grados franceses $1\text{ }^\circ\text{f} = 10\text{ ppm de }CaCO_3$), salinidad y presencia de $CO_2$ y $O_2$ disueltos, los cuales provocan precipitación de incrustaciones calcáreas pétreas ($CaSO_4$, $CaCO_3$, $Mg(OH)_2$) y picaduras corrosivas en calderas y conducciones de vapor (fuente: Documento Adsorción e Intercambio Iónico, sección Tratamiento de Aguas para la Producción de Vapor).

---

## Vacíos de Información
- **Insumos y Logística de Aire Comprimido:** `[NO ENCONTRADO EN FUENTES]` Las fuentes no especifican consumo de aceites lubricantes, filtros coalescentes de línea ni refrigerantes sintéticos para compresores de aire.